
#ifndef Nova_Fibonacci_h
#define Nova_Fibonacci_h

#include "Arduino.h"


class Nova_Fibonacci
{

  public:
    Nova_Fibonacci(int num);
    unsigned long Fibonacci_Iterative(int num);
    unsigned long Fibonacci_Recursive(int num);

    void test_Both_Sequence(int test_Num);
 
    int num_To_Calculate;
  private:
 
 };

#endif
