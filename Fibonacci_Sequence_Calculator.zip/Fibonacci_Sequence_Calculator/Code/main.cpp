/*

Code: Fibonacci Sequence Calculator:
Project: Code 

File Name: Fibonacci_Code_Test
Written By: Tanuj Siddharth

*/

#include <iostream>
#include <string>
using namespace std;

//// main /////////////////////////////////////////////////////////////////////////////



int main() {

	// Test Cases Variables
	int test_Num_Input;

	//GET USER INPUT 
	cout << "Enter a Number to Find Out the Fibonacci value at that position: ";
	cin >> test_Num_Input;

	// TEST CODE
	test_Both_Sequence(test_Num_Input);

	int exit_Code;

	// PRESS ENTER TO END TESTING PROMT
	cout << "Enter exit code 0 to finish: ";
	cin >> exit_Code;;
	//

	return 0;
}


/*////////////////////////////////////////// FUNCTION /////////////////////////////////
// Function Type: Sequence Calculation - Fibonacci Recursive Solution

// Function Use: Executives Recursive Fibonacci Calculations
//
// KEYWORDS: FIBONACCI, RECURSIVE, RECURSION

int fibonacci_Recursive(int num)


// Written By Tanuj Siddharth
///////////////////// IO //////////////////////////////////////////////////////////////
INPUT:
int num - "Position Number of the fibonacci Sequence"

OUTPUT:
Calculate the value at given position using recursive method

RETURN:
int fibonacci_Recursive(num - 1) + fibonacci_Recursive(num - 2);
////////////////////////////////////////////////////////////////////////////////////*/


int fibonacci_Recursive(int num) {
	if (num == 0)
		return 0;
	else if (num == 1)
		return 1;
	else
		return fibonacci_Recursive(num - 1) + fibonacci_Recursive(num - 2);
}


/*////////////////////////////////////////// FUNCTION /////////////////////////////////
// Function Type: Sequence Calculation - Fibonacci Iterative Solution

// Function Use: Executives Iterative Fibonacci Calculations
//
// KEYWORDS: FIBONACCI, ITERATIVE, ITERATION

int fibonacci_Iterative(int num)


// Written By Tanuj Siddharth
///////////////////// IO //////////////////////////////////////////////////////////////
INPUT:
int num - "Position Number of the fibonacci Sequence"

OUTPUT:
Calculate the value at given position using iterative method

RETURN:
int nth_Value - nth fibonacci Number
////////////////////////////////////////////////////////////////////////////////////*/



int fibonacci_Iterative(int num) {
	// Initialized Variables
	int num_Minus_1 = 0;
	int num_Minus_2 = 1;	// Initialized to 0 for first iteration
	int nth_Value = 1;			// This is the final variable returned in the end & the sum of two values during iterative stage
								// 
	if (num <= 1) {
		return num;
	}
	else {
		for (int i = 2; i < num; i++) {
			num_Minus_1 = num_Minus_2;
			num_Minus_2 = nth_Value;
			nth_Value = num_Minus_2 + num_Minus_1;
		}
		return nth_Value;
	}
}


/*////////////////////////////////////////// FUNCTION /////////////////////////////////
// Function Type: Test Function:
// Function Use: Executives Sequece Calculations
//
// KEYWORDS: TEST, BOTH,

void test_Both_Sequence(int test_Num)


// Written By Tanuj Siddharth
///////////////////// IO //////////////////////////////////////////////////////////////
INPUT:
int Test_Num - "Position Number of the fibonacci Sequence"

OUTPUT:
Print Respetive Sequence Calculations

RETURN:
null
////////////////////////////////////////////////////////////////////////////////////*/


void test_Both_Sequence(int test_Num) {

	cout << " Fibonacci Recursive: ";	cout << fibonacci_Recursive(test_Num) << endl;

	cout << " Fibonacci Iterative: ";   cout << fibonacci_Iterative(test_Num) << endl;

}



